# Changelog

Tutte le modifiche rilevanti del progetto sono elencate qui.
Il formato segue [Keep a Changelog](https://keepachangelog.com/it-IT/1.1.0/) e le versioni seguono il [Semantic Versioning](https://semver.org/lang/it/).

## [1.6.1] - 2026-11-20

Versione PATCH: nessuna funzione nuova; cambiano solo da dove il menu legge aggiornamenti e collegamenti, e il repository si allinea agli standard comuni dei progetti.

### Modificato
- **Cerca aggiornamento** legge `version.json` e `CHANGELOG.md` da `raw.githubusercontent.com` invece che dall'API di GitHub (limite di 60 richieste l'ora). Lo zip si scarica dalla radice del repository; le release non vengono più lette.
- **`links.json` nel formato comune** e letto da `raw.githubusercontent.com`. Host controllati per collegamento: GitHub solo su github.com, Discord su discord.gg o discord.com, Ko-fi su ko-fi.com, documentazione su mashaup.github.io.
- Nuovi collegamenti **Novità**, **Segnala un problema** e **Proponi un'idea** (modelli su GitHub) in **Sostieni › Community e aiuto**. Le icone in basso a sinistra restano GitHub, Discord, Ko-fi e Guida.
- `version.json` contiene anche lo SHA-256 dello zip e le novità della versione.

### Repository
- `npm test` (controlli del repository, ESLint, test di unità), `npm run build` e `npm run package` al posto di `tools/package.sh` e `tools/package.ps1`.
- Workflow `ci.yml` a ogni push e `release.yml` alla pubblicazione di una release: test, zip e SHA-256 allegati alla release, annuncio su Discord.
- `SECURITY.md`, modelli per segnalare un problema o proporre un'idea.
- Documentazione ridotta: README più corto; `docs/MANUTENZIONE.md` e `docs/COMPATIBILITA.md` divisi in `docs/ARCHITECTURE.md`, `docs/TEST_PLAN.md`, `docs/RELEASE.md` e `docs/SITE_NOTES.md`.

Nessun permesso nuovo.

## [1.6.0] - 2026-10-24

### Aggiunto
- **Collegamenti ufficiali** in un'unica fonte (`src/lib/links.js`): GitHub, Discord, Ko-fi e guida come piccole icone in basso a sinistra nel menu e nell'elenco "Community e aiuto" della sezione Sostieni. Pagine per segnalare problemi e proporre funzioni predisposte ma spente finché non vengono confermate.
- **Collegamenti aggiornabili senza nuova versione**: il menu legge `links.json` dal repository GitHub (al massimo ogni 12 ore, o con "Cerca aggiornamento"). Solo dati, validati campo per campo; indirizzi solo `https` su domini noti; con rete assente o file non valido si usano l'ultima configurazione valida o quella di serie.
- **Parti anche con il browser ridotto a icona** (attivo di serie): con la scheda nascosta, se il nuovo episodio non parte o il player lo rimette in pausa, l'estensione riprova per circa un minuto (sei tentativi), poi avvisa e lo avvia al ritorno. Ogni esito finisce in cronologia.

### Modificato
- **Icona per la barra del browser** (16 e 32 px) senza quadrato di sfondo: l'anello occupa tutta l'icona e appare grande quanto quelle delle altre estensioni.
- Indirizzi di Ko-fi e del repository nel menu presi dalla nuova fonte unica.

## [1.5.2] - 2026-10-20

### Corretto
- **Verifica tutto, "Sito riconosciuto"**: poteva risultare in errore ("manca l'iframe dell'episodio") anche con tutto funzionante, se l'iframe dell'episodio rispondeva in ritardo. Ora si aspettano le risposte di pagina, iframe e player (fino a 3 secondi) e basta che risponda l'iframe dell'episodio o il player; se l'errore è vero, il testo dice quali iframe ci sono nella pagina.
- I risultati di Verifica tutto fatti con una versione precedente non vengono più mostrati: dopo un aggiornamento la verifica va rifatta.

### Modificato
- **Nome visualizzato "Keep Watching"** (senza trattino basso) nel browser, nel menu, nelle notifiche e sul player. Repository, cartella e zip restano `Keep_Watching`.
- **Icona ancora più grande**: il simbolo occupa quasi tutto il quadrato.

## [1.5.1] - 2026-10-20

### Corretto
- **Player su vixcloud.cc**: il sito ha spostato il player da vixcloud.co a vixcloud.cc e lo script del player non partiva più (niente cambio episodio, salti, barra, avvio con audio). Ora sono supportati entrambi i domini.
- **Riconoscimento del sito**: la pagina dell'episodio è riconosciuta anche quando la pagina principale non risponde in tempo a Verifica tutto, e gli iframe con indirizzo relativo vengono letti correttamente.

### Aggiunto
- **Dominio del player nella diagnosi**: se il player sta su un dominio non ancora supportato, Centro salute e cronologia lo indicano per nome ("Player su un dominio non supportato: …"); se nella pagina non c'è un player supportato, elencano gli host degli iframe trovati.
- **Elenco unico dei domini del player** (`src/hosts.js`), con test.

### Modificato
- **Icona più grande**: il simbolo riempie di più il quadrato, soprattutto a 16 e 32 px (barra del browser).

## [1.5.0] - 2026-10-20

### Aggiunto
- **Centro salute** nel menu: stato reale della scheda (sito, player, prossimo episodio, ripresa, ultimo errore) e **Verifica tutto**, che controlla sito, iframe e permesso di autoplay, player, controlli, prossimo episodio, salti, ripresa, memoria ed errori recenti senza toccare il video. Tre esiti (Funzionante, Da verificare, Non disponibile) con il dettaglio: disattivata da te, non attiva adesso, non supportata, in errore, non provata.
- **Cronologia eventi** locale: player e pagina riconosciuti, cambi di episodio con l'esito, conto alla rovescia, salti, blocchi e tentativi di ripresa con l'esito, errori del video, risultati delle verifiche. Eventi ripetuti raggruppati, al massimo 300, senza indirizzi completi né token; esportazione JSON e cancellazione.
- **Stato della scheda nella Panoramica**: con accesso rapido a Verifica tutto, Centro salute e Cronologia.
- **Macchina a stati del player** (`src/lib/health.js`): in caricamento, pronto, in riproduzione, in pausa, caricamento dati, bloccato, recupero in corso, cambio episodio, finito, errore recuperabile, serve un'azione, non compatibile.
- **Verifica del cambio episodio**: se il clic su "prossimo episodio" non ha effetto entro 15 secondi si riprova una volta, poi compare "Cambio episodio non riuscito" con **Riprova** (e una notifica se la scheda è nascosta).
- **Ripresa con esito verificato**: dopo la ricarica il recupero è riuscito solo se il video riparte entro 20 secondi.
- Riconoscimento della pagina dell'episodio (`src/site-health.js`): segnala le pagine senza player (errore o manutenzione del sito) e i player senza video.
- **Nuova icona**: anello viola-azzurro con freccia e play, e accento coordinato nel menu e sul player; icone vettoriali al posto dei caratteri nei riquadri del player.
- **Documento di compatibilità** (`docs/COMPATIBILITA.md`): audit, siti supportati, matrice dei guasti, piani di ripresa.

### Corretto
- Con il cambio automatico spento o l'estensione sospesa, qualsiasi scrittura nello storage (per esempio le statistiche ogni 15 secondi) chiudeva i riquadri del player, anche quello del timer di spegnimento.
- Il pulsante "prossimo episodio" veniva cliccato anche se disattivato, e un pulsante comparso con qualche secondo di ritardo risultava mancante.
- Il salto di recupero con durata del video sconosciuta generava un errore.
- Un caricamento interrotto (cambio pagina) provocava una ricarica dell'episodio; ora gli errori del video sono classificati per codice.
- Se nessuna pagina del sito raccoglieva la richiesta di ricarica, il player non lo sapeva: ora lo dice e chiede di ricaricare a mano.
- Riconoscimento dell'iframe del player più preciso: serve l'host vixcloud.co, non basta la parola nell'indirizzo.

### Sicurezza
- Le operazioni che cancellano o sostituiscono dati (azzeramento e importazione delle statistiche, cancellazione della cronologia) e Verifica tutto sono accettate solo dalle pagine dell'estensione, non dagli script nelle pagine del sito. Ogni messaggio deve provenire dall'estensione stessa.

### Modificato
- Il menu segnala quando un'impostazione non è stata salvata (memoria del browser piena o non disponibile).
- Nessun permesso nuovo.

## [1.4.1] - 2026-10-18

### Aggiunto
- **Pulsanti sulla barra a scelta**: in Interfaccia sul video › Barra dei controlli ogni pulsante (Salta intro, salto avanti, Fine intro qui, Inizio titoli qui, Stop a fine episodio, "?") si può togliere singolarmente, con l'anteprima e le scelte rapide "Solo Salta intro e salto avanti" e "Tutti". Se non ne scegli nessuno la barra non compare. Le scorciatoie da tastiera funzionano anche con il pulsante nascosto.

### Modificato
- La "Modalità minimale" è sostituita dalla scelta dei pulsanti: chi l'aveva attiva ritrova gli stessi pulsanti (Salta intro e salto avanti). "Ripristina aspetto" rimette anche tutti i pulsanti.
- Impostazioni migrate allo schema 3.

## [1.4.0] - 2026-10-17

### Aggiunto
- **Nuovo menu a sezioni**: Panoramica, Riproduzione, Interfaccia sul video, Profili, Statistiche, Aggiornamenti e Sostieni, con tema scuro ispirato a StreamingCommunity. Si può aprire anche in una scheda (pulsante in basso a sinistra).
- **Profili**: Normale, Notturno, Maratona e Manuale. Applicano un gruppo di impostazioni in un colpo; se poi ne cambi una, il menu indica "Personalizzato" e permette di ripristinare il profilo. Non toccano timer, limite di episodi, aspetto e statistiche.
- **Popup sul video per categoria**: conto alla rovescia, conferme di intro e titoli, domanda dopo N episodi, timer di spegnimento, streaming bloccato, altri messaggi. Più l'interruttore "Nascondi tutti i popup sul video", che non spegne nessuna automazione e conserva le scelte per categoria.
- **Salto avanti regolabile**: 15, 30, 45, 60 o 90 secondi, con scorciatoia Alt+Shift+→.
- **Guida alle scorciatoie sul player** (Alt+Shift+H o pulsante "?"): mostra le combinazioni assegnate, quelle mancanti e i possibili conflitti; si chiude con Esc, con "Chiudi" o da sola se lo imposti.
- **Scorciatoie** Alt+Shift+S (salta intro) e, senza combinazione predefinita, "Segna fine intro", "Segna inizio titoli", "Stop a fine episodio". Non scattano mentre stai scrivendo in un campo di testo.
- **Aspetto della barra sul player**: dimensione, densità, opacità dello sfondo, posizione, tempo prima di nascondersi, modalità minimale, animazioni ridotte (rispetta anche l'impostazione di sistema), con anteprima nel menu e "Ripristina aspetto".
- **Statistiche locali**: tempo di visione reale (pause e caricamenti esclusi), sessioni, durata media, episodi completati, intro e titoli saltati, per oggi, 7 o 30 giorni, con grafico giornaliero e tabella. Restano solo sul computer; si possono disattivare e azzerare.
- **Esportazione CSV e JSON** delle statistiche e **importazione** del JSON (unisci o sostituisci, senza duplicati).
- **Centro aggiornamenti**: pulsante "Cerca aggiornamento" che legge il repository GitHub ufficiale (release, oppure `version.json` e `CHANGELOG.md`), con versione installata e ultima pubblicata, novità, registro delle versioni, download dello zip e verifica reale dopo la ricarica. Controllo automatico facoltativo al massimo una volta al giorno. Nessuna installazione automatica.
- **Novità dopo un aggiornamento**, mostrate una volta nel menu (mai sul video).
- **Sezione Sostieni** con il link a Ko-fi.

### Corretto
- **Il pulsante "+60 s" spariva** dopo i primi 3 minuti (o veniva sostituito da "Salta intro"): ora resta disponibile per tutto l'episodio e si può premere più volte di seguito; vicino alla fine si ferma un secondo prima.
- Dopo vari salti in avanti di seguito il controllo "streaming bloccato" poteva scattare per errore.
- Il riquadro "Intro saltata" non blocca più il cambio automatico dell'episodio.

### Modificato
- Impostazioni validate a ogni lettura e migrate all'aggiornamento (schema 2): valori fuori elenco tornano a quelli predefiniti.
- Nuove librerie `src/lib/stats.js` e `src/lib/updates.js`, con test automatici in `tests/`.

## [1.3.0] - 2026-10-09

### Aggiunto
- **Salto intro per serie**: con il pulsante "Fine intro qui" sul player si segna la fine dell'intro; negli episodi successivi della serie viene saltata da sola, con un riquadro "Intro saltata" e il pulsante "Annulla". Non scatta se l'episodio riparte da un punto preciso (`minute=` o ricarica).
- **Titoli di coda per serie**: "Inizio titoli qui" salva per la serie quanti secondi prima della fine iniziano i titoli; ha la precedenza sul valore generale.
- **Barra di pulsanti sul player** (`src/toolbar.js`): "Salta intro", "+60 s", "Fine intro qui", "Inizio titoli qui", "Stop a fine episodio". Compare muovendo il mouse sul video.
- **Timer di spegnimento**: dopo 15–90 minuti, alla fine dell'episodio o alla fine della stagione, con dissolvenza del volume negli ultimi 30 secondi (opzionale). Il volume viene ripristinato a video fermo.
- **Streaming bloccato**: se il video non avanza per 12 secondi viene fatto un salto di 1 secondo; se non basta, l'episodio viene ricaricato tramite l'iframe del sito con `minute=` e riportato al secondo in cui suonava (`src/recovery.js`). Se si blocca di nuovo entro 3 minuti arriva una notifica.
- **Pausa quando cambi scheda** (facoltativa, disattivata di default).
- Nel menu: sezioni, timer di spegnimento con orario di fine, elenco delle serie salvate con "Rimuovi".

## [1.2.1] - 2026-10-05

Versione di manutenzione: nessuna funzione nuova, comportamento invariato.

### Modificato
- Il riquadro sul player (conto alla rovescia e domande) è stato spostato da `player.js` nel nuovo file `src/panel.js`.
- `player.js`: dati dell'episodio letti una sola volta dall'URL; decodifica del titolo con `TextDecoder` al posto della funzione deprecata `escape()`; avvio del nuovo episodio semplificato (un solo percorso per il tentativo con e senza audio); listener degli eventi video unificati; plurali corretti nei messaggi ("1 episodio").
- `autoplay-permission.js` interviene solo sull'iframe del player, e non più sugli iframe senza URL di altri siti con `/watch/` o `/iframe/` nel percorso.
- `cinema.js` controlla l'URL della pagina solo mentre la modalità cinema è attiva, invece che ogni secondo in ogni momento.
- `background.js`: avvio del browser e installazione condividono la stessa funzione.
- CSS del menu riordinato, senza regole duplicate.
- Descrizione dell'estensione aggiornata alle funzioni attuali.
- `tools/package.sh` e `tools/package.ps1` aggiornano da soli il nome dello zip nel README; `package.ps1` legge e scrive i file in UTF-8 anche su Windows PowerShell 5.1.

## [1.2.0] - 2026-10-05

### Aggiunto
- **Conto alla rovescia annullabile** prima del cambio episodio: un riquadro sul player, visibile anche a schermo intero, con i pulsanti "Annulla" e "Vai ora". Durata da 5 a 20 secondi, oppure cambio immediato.
- **Interruttore generale** in cima al menu e **scorciatoia da tastiera** (predefinita Alt+Shift+K) per attivare o sospendere l'estensione.
- **Badge sull'icona**: "OFF" quando l'estensione è sospesa, "2/3" durante un limite di episodi.
- **Notifiche sul desktop** quando non ci sono altri episodi, quando si raggiunge il limite con la scheda nascosta e quando il pulsante "prossimo episodio" non viene trovato pur esistendo un episodio successivo (segno che il sito è cambiato). Cliccando la notifica si torna alla scheda.
- **Resta a schermo intero tra un episodio e l'altro** (attivabile dal menu): se si guarda a schermo intero, al cambio episodio la finestra del browser passa a schermo intero e il player la occupa tutta. Si esce con Esc o con il pulsante schermo intero del player.

### Modificato
- "Fermati dopo" diventa **"Chiedi se continuare dopo"**: al raggiungimento del limite un riquadro sul player chiede se passare al prossimo episodio ("Continua") o fermarsi ("Basta così"), invece di fermarsi in silenzio.
- Nuovo service worker (`src/background.js`) e nuovo script `src/cinema.js`; nuovo permesso `notifications`.

## [1.1.0] - 2026-10-02

### Aggiunto
- Opzione **Personalizzato…** in "Salta i titoli di coda": si sceglie con minuti e secondi quanto prima della fine cambiare episodio. Un anticipo più lungo dell'episodio viene ignorato.
- Nei log, lo stato della scheda (`[scheda visibile]` / `[scheda nascosta]`) nei momenti chiave del cambio episodio.

### Modificato
- Lo zip di installazione contiene ora la cartella `Keep_Watching/`: estraendolo si ottiene direttamente la cartella da caricare nel browser.
- L'attesa del player nel nuovo episodio usa gli eventi del video invece di un ciclo di timer, che Chrome rallenta nelle schede nascoste.
- Finestra ridotta a icona: se il nuovo episodio non parte o viene rimesso in pausa mentre la scheda è nascosta, l'estensione riprova l'avvio appena la scheda torna visibile.
- `.gitignore` esclude la cartella `_metadata/` creata dal browser.

## [1.0.0] - 2026-09-30

Prima versione pubblicata.

### Aggiunto
- Passaggio automatico all'episodio successivo a fine episodio, con click sul pulsante "prossimo episodio" del player.
- Avvio automatico con audio del nuovo episodio, anche dopo un click manuale su "prossimo episodio".
- Permesso di autoplay per l'iframe del player (`allow="autoplay"`), senza il quale il browser bloccava l'audio.
- Menu dall'icona con le opzioni: prossimo episodio automatico, avvio del nuovo episodio, salta i titoli di coda (da 15 secondi a 2 minuti prima della fine), fermati dopo N episodi di fila.
- Funzionamento indipendente dal dominio principale del sito, che cambia periodicamente.
- Icone e script di utilità in `tools/` (rigenerazione icone, creazione del pacchetto zip).
